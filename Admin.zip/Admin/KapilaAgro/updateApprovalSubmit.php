 <?php

 include 'connection.php';

 if(isset($_POST['done'])){

 $id = $_GET['id'];
 $referenceNo = $_POST['referenceNo'];
 $applicationNo = $_POST['applicationNo'];
 $applicantName = $_POST['applicantName'];
 $applicantAddress = $_POST['applicantAddress'];
 $siteName = $_POST['siteName'];
 $bankName = $_POST['bankName'];
 $accountType = $_POST['accountType'];
 $branchAddress = $_POST['branchAddress'];
 $accountNumber = $_POST['accountNumber'];
 $IFSC = $_POST['IFSC'];
 $nameOfAccount = $_POST['nameOfAccount'];
 $rent = $_POST['rent'];
 $advance = $_POST['advance'];
 $agreementLetterNumber = $_POST['agreementLetterNumber'];
 $q = " update add_approval_data set id=$id, referenceNo='$referenceNo', applicationNo='$applicationNo', applicantName='$applicantName', applicantAddress='$applicantAddress', siteName='$siteName', bankName='$bankName', accountType='$accountType', branchAddress='$branchAddress', accountNumber='$accountNumber' IFSC='$IFSC', nameOfAccount='$nameOfAccount', rent='$rent', advance='$advance', agreementLetterNumber='$agreementLetterNumber' where id=$id  ";

 $query = mysqli_query($db,$q);

 header('location:approval.php');
 }

?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Update Approval Letter Details </h1>
 </div><br>

 <label> Reference Number </label>
 <input type="text" name="referenceNo" class="form-control"> <br>

 <label> Application Number </label>
 <input type="text" name="applicationNo" class="form-control"> <br>
	
	<label> Applicant Name </label>
 <input type="text" name="applicantName" class="form-control"> <br>
 
 <label> Applicant Address </label>
 <input type="text" name="applicantAddress" class="form-control"> <br>
 
 <label> Site Name </label>
 <input type="text" name="siteName" class="form-control"> <br>
 
  <label> Bank Name </label>
 <input type="text" name="bankName" class="form-control"> <br>
 
  <label> Account Type </label>
 <input type="text" name="accountType" class="form-control"> <br>
 
  <label> Branch Address </label>
 <input type="text" name="branchAddress" class="form-control"> <br>
 
  <label> Account Number </label>
 <input type="text" name="accountNumber" class="form-control"> <br>
 
  <label> IFSC Code </label>
 <input type="text" name="IFSC" class="form-control"> <br>
 
  <label> Name Of Account </label>
 <input type="text" name="nameOfAccount" class="form-control"> <br>
 
  <label> Rent </label>
 <input type="text" name="rent" class="form-control"> <br>
 
  <label> Advance </label>
 <input type="text" name="advance" class="form-control"> <br>
 
  <label> Agreement Letter Number </label>
 <input type="text" name="agreementLetterNumber" class="form-control"> <br>
 
 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>
 <br>

 </div>
 </form>
 </div>
</body>
</html>