 <?php

include 'connection.php';

$id = $_GET['id'];

$query = "DELETE FROM invoicedetail WHERE id = '". (int) $id ."'";

// run the delete query
mysqli_query($db, $query);

// close the db connection
mysqli_close($db);
	echo "<center><br><br><br><br><div id=p2><br><p>Data has been succcessfully updated</p></div></center>";
        echo "<center><a href='../KapilaAgro/showInvoiceDetail.php'><button type='button'>Go Back to Admin page</button></a></div></center>";

?>