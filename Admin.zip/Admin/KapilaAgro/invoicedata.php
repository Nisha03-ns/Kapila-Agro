<?php
include("connection.php");

	if(isset($_POST['search_by_Mobile']))
	{
    $id = $_POST['get_Mobile'];
	
	
    $sql="SELECT * FROM invoicedetail WHERE Mobile='".$id."'";
    $result=mysqli_query($db,$sql);
	
	
	 if(mysqli_num_rows($result) > 0)                
	               {
		           while($row = mysqli_fetch_array($result))
		           {

    
 
?>
<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


input[type=print] {
	
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=print]:hover {
  background-color: #45a049;
}
button {
	background: #2B6BB5;
	padding: 8px 20px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}

</style>
</head>
<body>
<div class="container">
	<center><h2>Invoice Details</h2>
		<img  src="images/demo/logo.png" style="height: 100px">
	</center>
	<div class="container">
		<p style="float:right">
		KAPILA AGRO PRIVATE LTD.<br>
		Head Office Address -<br>
		Nalawadi,Post office & Nvalgund,<br>
		Dharwad, Karnatka,India<br>
		Pincode - 580023<br><br>
		Corporate Office -<br>
		Krishnagar Akola<br>
		Akola, Maharastra, India<br>
		Pincode - 444104<br>
		<p> __________________________________________________________________________________________________________________________________</p>
</div>
 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h4> Invoice Details </h4>
 
 <tr class="text-center">
 <tr><td>Bill To : </td></tr>
 <tr><td> <?php echo $row['BillTo'];  ?> </td></tr><br>
 <tr><td>Contact Number : </td></tr>
 <tr><td> <?php echo $row['Mobile'];  ?> </td></tr><br>
 <tr><td> Address : </td></tr>
<tr> <td> <?php echo $row['Address'];  ?> </td></tr><br>
 <tr><td>Pincode : </td></tr>
 <tr><td> <?php echo $row['Pincode'];  ?> </td></tr><br>
  <tr><td>Invoice# : </td></tr>
 <tr><td> <?php echo $row['Invoice'];  ?> </td></tr><br>
 <tr><td>Invoice Date : </td></tr>
 <tr><td> <?php echo $row['InvoiceDate'];  ?> </td></tr><br>
  <tr><td>Status : </td></tr>
 <tr><td> <?php echo $row['Status'];  ?> </td></tr><br>
 <tr><td>Investment Charge : </td></tr>
 <tr><td> <?php echo $row['InvestmentCharge'];  ?> </td></tr><br>
 <tr><td>SubTotal : </td></tr>
 <tr><td> <?php echo $row['SubTotal'];  ?> </td></tr><br>
 <tr><td>18% GST  for Indian Residency only : </td></tr>
 <tr><td> <?php echo $row['GST'];  ?> </td></tr><br>
  <tr><td>Total : </td></tr>
 <tr><td> <?php echo $row['Total'];  ?> </td></tr><br>
 __________________________________________________________________________________________________________________________________</p><br>
 
 <div class="container">
<p><b>Terms & Conditions</b><br>
<b>Please submit complete address</b></p>
<p> 1. Self attested copy of Aadhaar Card<br>
2. Self attested copy of PAN card<br>
3. Self attested passport size photograph (two)<br>
4. Copy of property related documents<br>
5. Copy of bank pass book (Front Page)<br>
6. A photograph of the space applied for Kapila Agro Franchise<br>
7. Processing amount and agreement fee is refundable within 21 days<br>
8. Site servey (ground fisiblity) done within 7 days after submiting processing amount.<br>
9. Agreement done within 10 days<br>
10. Mothly rental starts on dated agreement.<br>
11. Advance amount release after agreement within 2 days.<br>
12. Total working days of project is approx 45 -60 days.<br>
<b>Note-</b> vender name/account id head<br>

<p> 
 __________________________________________________________________________________________________________________________________</p><br><h5><b>COMPANY ACCOUNT DETAILS:-<b></h5>
<p><b>Through NetBanking,NEFT,RTGS,IMPS Only:</b><br>
</div>

<tr class="text-center">
 <tr><td>Company Name : </td></tr>
 <tr><td> <?php echo $row['Company_Name'];  ?> </td></tr><br>
 <tr><td>Account Number : </td></tr>
<tr> <td> <?php echo $row['AccountNumber'];  ?> </td></tr><br>
<tr><td>Account Type : </td></tr>
<tr> <td> <?php echo $row['AccountType'];  ?> </td></tr><br>
 <tr><td>Bank : </td></tr>
 <tr><td> <?php echo $row['Bank'];  ?> </td></tr><br>
  <tr><td>IFSC : </td></tr>
 <tr><td> <?php echo $row['IFSC'];  ?> </td></tr><br>
  <tr><td>Branch : </td></tr>
 <tr><td> <?php echo $row['Branch'];  ?> </td></tr><br><br>
 __________________________________________________________________________________________________________________________________</p><br>
<table class="table table-bordered" >
<tr>
<th style="text-align:right"><h4 style="color:blue">Kapila agro authorized signature</h4></th>
</tr>
<tr>
<th colspan="4" style="text-align:right"><img class="btmspace-30" style="float:right" src="images/demo/signature.jpeg"></th>
</tr>
</table>

<div class="container">
<center>
	<script>
	function printpage() {

    //Get the print button and put it into a variable
    var printButton = document.getElementById("printpagebutton");
	

    //Set the button visibility to 'hidden' 
    printButton.style.visibility = 'hidden';

    //Print the page content
    window.print()

    //Restore button visibility
    printButton.style.visibility = 'visible';
	
} 
</script>
<div class="container">
<center><input id="printpagebutton" class="btn-btn-primary" type="button" value="Print" onclick="printpage()"/></center><br><br>


</div>
<br><br><br>
</div>
 
</body>
</html>
<br><br><br>

  
<?php
    }
	 }
	 else
	 {
		 ?>
		 <tr>
		      <center><br><br><br><br><div id=p2><br><p> Your invoice letter is being processes.Please try again later....</p></div></center>
<center><a href='../KapilaAgro/index.php'><button type='button'>Home</button></a></div></center>
		 </tr>
		 <?php
		 
	} }
   ?>