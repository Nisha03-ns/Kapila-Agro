<?php
include("connection.php");


 ?>
 <!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4B7AAF;
  color: white;
}
</style>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="admin.php">GO Back to Admin Panel Dashboard</a> 
| 
<h2>View Records</h2>
<table id="customers" width="50%" border="2" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>Company Name</strong></th>
<th><strong>Bank Name</strong></th>
<th><strong>Account Number</strong></th>
<th><strong>Account Type</strong></th>
<th><strong>IFSC</strong></th>
<th><strong>Branch Address</strong></th>

</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="Select * from invoicedetail order by id desc;";
$result = mysqli_query($db,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td align="center"><?php echo $row["Company_Name"]; ?></td>
<td align="center"><?php echo $row["Bank"]; ?></td>
<td align="center"><?php echo $row["AccountNumber"]; ?></td>
<td align="center"><?php echo $row["AccountType"]; ?></td>
<td align="center"><?php echo $row["IFSC"]; ?></td>
<td align="center"><?php echo $row["Branch"]; ?></td>

</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
