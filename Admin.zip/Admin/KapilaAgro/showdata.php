<?php
include("connection.php");


 ?>
 <!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4B7AAF;
  color: white;
}
</style>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="admin.php">GO Back to Admin Panel Dashboard</a> 
| 
<h2>View Records</h2>
<table id="customers" width="50%" border="2" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>ID</strong></th>
<th><strong>Name</strong></th>
<th><strong>MotherName</strong></th>
<th><strong>FatherName</strong></th>
<th><strong>Email</strong></th>
<th><strong>Mobile</strong></th>
<th><strong>Town</strong></th>
<th><strong>Area</strong></th>
<th><strong>Pincode</strong></th>
<th><strong>District</strong></th>
<th><strong>State</strong></th>
<th><strong>Investment</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="Select * from addcustomer order by id desc;";
$result = mysqli_query($db,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td align="center"><?php echo $row["id"]; ?></td>
<td align="center"><?php echo $row["Name"]; ?></td>
<td align="center"><?php echo $row["MotherName"]; ?></td>
<td align="center"><?php echo $row["FatherName"]; ?></td>
<td align="center"><?php echo $row["Email"]; ?></td>
<td align="center"><?php echo $row["Mobile"]; ?></td>
<td align="center"><?php echo $row["Town"]; ?></td>
<td align="center"><?php echo $row["Area"]; ?></td>
<td align="center"><?php echo $row["Pincode"]; ?></td>
<td align="center"><?php echo $row["District"]; ?></td>
<td align="center"><?php echo $row["State"]; ?></td>
<td align="center"><?php echo $row["Investment"]; ?></td>

</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
