<?php
include("connection.php");
?>
<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="index.php">कपिला  Agro</a></h1>
    <img  src="images/demo/logo.png" style="float:right;position: absolute;top: 2px;right: 8px;font-size: 18px; height: 120px">
	</div>
  </header>
</div>
<div class="wrapper row2">
  <nav id="mainav" class="hoc clear"> 
    <ul class="clear">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a class="drop" href="">Product</a>
        <ul>
          <li><a class="drop" href="#">Kapila Pashu Ahar</a>
            <ul>
              <li><a href="BuffaloSpecialKapila.php">Buffalo Special</a></li>
              <li><a href="DairySpecialKapila.php">Dairy Special</a></li>
              <li><a href="UttamPalletKapila.php">Uttam Pallet (Super)</a></li>
			   <li><a href="SantulitPalletKapila.php">Santulit Pallet (Balance)</a></li>
            </ul>
          </li>
		  <li><a class="drop" href="#">Milkomore Pashu Ahar</a>
            <ul>
              <li><a href="BuffaloSpecialMilkomore.php">Buffalo Special</a></li>
              <li><a href="DairySpecialMilkomer.php">Dairy Special</a></li>
              <li><a href="UttamPalletMilkomore.php">Uttam Pallet (Super)</a></li>
			   <li><a href="SantulitPalletMilomore.php">Santulit Pallet (Balance)</a></li>
            </ul>
          </li>  
        </ul>
      </li>
	  <li><a class="drop" href="#">Bussiness</a>
        <ul>
          <li><a  href="KapilaFMCG.php">Kapila (FMCG)</a> </li>
           <li><a  href="Ubrbancrave.php">Ubrbancrave</a>  </li>
           <li><a  href="wholesale.php">Hundred Wholesale</a>  </li>
		  </ul></li>
      <li><a href="gallery.php">Media</a></li>
      <li><a href="contact.php">Contact Us</a></li>
	   <li><a href="apply.php">Apply Online</a></li>
      <li><a href="checkStatus.php">Check Status</a></li>
    </ul>
  </nav>
</div>
<div class="wrapper bgded overlay" style="background-image:url('images/demo/bg1.jpeg');">
  <div id="pageintro" class="hoc clear"> 
    <article>
      <div>
        <p class="heading">Kapila Agro</p>
        <p>Kapila Agro Group, is one of the major animal feed producer in India with a production capacity is about to 1600 MT of cattle feed per day. Since long time, the company has expanded and brings up very close relationship with farmers by providing them best quality of products.</p>
      </div>
      <footer>
        <ul class="nospace inline pushright">
        </ul>
      </footer>
    </article>
  </div>
</div>
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <article class="group">
      <div class="group btmspace-80">
        <div class="one_quarter first">
          
          <h6 class="heading">Kapila Agro</h6>
        </div>
        <div class="three_quarter">
          <p>Kapila Agro Group, is one of the major animal feed producer in India with a production capacity is about to 1600 MT of cattle feed per day. Since long time, the company has expanded and brings up very close relationship with farmers by providing them best quality of products. Also, we are providing them creative and innovative ideas to produce cattle feed as well as educating them on farming and animal husbandry practices </p>
          <p class="btmspace-30">Nowadays, with more than 100 educated people and three large-scale manufacturing companies, including with 3 automates and 3 semi-automated plants are involved with Kapil Agro Family. Places like Uttar Pradesh and Punjab along with 700 networks, C&F, distributors, dealers, agents are part of this family. We proud that we are the market leader in animal feed in North India.</p>
          <footer><a class="btn" href="#">Read More &raquo;</a></footer>
        </div>
      </div>
      <figure>
        <ul class="nospace group overview">
          <li class="one_half"><img src="images/demo/milk.jpeg" alt=""></li>
          <li class="one_half"><img src="images/demo/chara.jpeg" alt=""></li>
          <li class="one_half"><img src="images/demo/hut.jpeg" alt=""></li>
          <li class="one_half"><img src="images/demo/mb.jpeg" alt=""></li>
          
        </ul>
      </figure>
    </article>
    <div class="clear"></div>
  </main>
</div>
<div class="wrapper row3" >
  <section class="hoc container clear" > 
    <div class="sectiontitle">
      <h6 class="heading">_____Our Products_____</h6>
      <p>We believe in our products.</p>
    </div>
    <div class="group" >
      <article class="one_third first"  style = "margin-left: 200px;" ><a href="#"><img class="btmspace-30" src="images/demo/bs.png" align="center"></a>
        <center><h6 class="nospace heading">Buffalow Special</h6><br>
        <footer class="nospace"><a class="btn" href="apply.php">Apply Online</a></footer></center>
      </article>
      <article class="one_third"><a href="#"><img class="btmspace-30" src="images/demo/ds.png" alt=""></a>
        <center><h6 class="nospace heading">Dairy Special</h6><br>
        <footer class="nospace"><a class="btn" href="apply.php">Apply Online</a></footer><center>
      </article><br><br><br><br><br><br><br><br><br><br><br><br>

      <article class="one_third" style = "margin-left: 200px;"><a href="#"><img class="btmspace-30" src="images/demo/up.png" alt=""></a>
        <center><h6 class="nospace heading">Uttam Pallet (Super)</h6><br>
        <footer class="nospace"><a class="btn" href="apply.php">Apply Online</a></footer></center>
      </article></br></br></br></br>
	  <article class="one_third"><a href="#"><img class="btmspace-30" src="images/demo/sp.png" alt="" ></a>
       <center><h6 class="nospace heading">Santulit Pallet (Balance)</h6><br>
        <footer class="nospace"><a class="btn" href="apply.php">Apply Online</a></footer></center>
      </article>
	    <br><br>
    </div>
  </section>
</div>
<div class="wrapper bgded overlay light" style="background-color:#CBD5C4;">
  <article class="hoc cta clear"> 
    <h6>We continuously strive to make meaningful contributions to the communities of which we are part of. By working with our partners, we have now started to touch various places across the country.</h6>
    <footer class="one_quarter"></footer>
  </article>
</div>
<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
    <div class="one_quarter first">
      <h6 class="heading">About Us</h6>
      <ul class="nospace linklist">
        <li><a href="about.php">Company Introduction</a></li>
        <li><a href="about.php">Vision & Mission</a></li>
		<div class="one_quarter"><br><br>
      <h6 class="heading">Media</h6>
      <ul class="nospace linklist">
        <li><a href="gallery.php">Gallery</a></li>
		</ul>
        
    </div>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Products (Kapila Pashu Ahaar)</h6>
      <ul class="nospace linklist">
        <li><a href="BuffaloSpecialMilkomore.php">Buffalo Special</a></li>
        <li><a href="DairySpecialMilkomer.php">Dairy Special</a></li>
        <li><a href="UttamPalletMilkomore.php">Uttam Pallet (Super)</a></li>
		<li><a href="SantulitPalletMilomore.php">Santulit Pallet (Balance)</a></li>
      </ul><br>
	  <h6 class="heading">Products (Milkomore Pashu Ahaar)</h6>
      <ul class="nospace linklist">
        <li><a href="BuffaloSpecialMilkomore.php">Buffalo Special</a></li>
        <li><a href="DairySpecialMilkomer.php">Dairy Special</a></li>
        <li><a href="UttamPalletMilkomore.php">Uttam Pallet (Super)</a></li>
		<li><a href="SantulitPalletMilomore.php">Santulit Pallet (Balance)</a></li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Business</h6>
      <ul class="nospace linklist">
       <li><a  href="KapilaFMCG.php">Kapila (FMCG)</a> </li>
           <li><a  href="Ubrbancrave.php">Ubrbancrave</a>  </li>
           <li><a  href="wholesale.php">Hundred Wholesale</a>  </li><br><br><br>
		   <a href="apply.php"><h6 class="heading">Apply Online</h6></a>
			<a href="checkStatus.php"><h6 class="heading">Check Status</h6></a>
    </div>
	<div class="one_quarter">
      <h6 class="heading">Contact Us</h6>
      <ul class="nospace btmspace-30 linklist contact">
	  <li><i class="fa fa-map-marker"></i>
          <address>
          Head Office - Nalawadi Post office,&amp; Nvalgund, Dharwad, Karnataka, India(580023)
          </address>
        </li>
        <li><i class="fa fa-map-marker"></i>
          <address>
          Corporate Office - Krishnagar Akola &amp; Akola, Maharastra, India0(444104)
          </address>
        </li>
        <li><i class="fa fa-phone"></i> +91  834 685 4232</li>
        <li><i class="fa fa-envelope-o"></i> support@kapilaagro.in</li>
      </ul>
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
      </ul>
    </div>
  </footer>
</div>
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <center><p>Copyright &copy; 2017 - All Rights Reserved - kapilaagro.in</p></center>
  </div>
</div>
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>