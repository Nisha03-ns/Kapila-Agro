<?php 
 
include("connection.php");
if($_GET['id']) {
    $id = $_GET['id'];
 
    $sql="SELECT * FROM add_approval_data WHERE id='".$id."'";
    $result = $db->query($sql);
 
    $data = $result->fetch_assoc();
 
    $db->close();
 
?>
<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


input[type=print] {
	
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=print]:hover {
  background-color: #45a049;
}
button {
	background: #2B6BB5;
	padding: 8px 20px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}

</style>
</head>
<body>
<br>
<center><h1 id="q2">Make Changes in Approval letter...</h1></center><br><br><br>
<div id="p4">
    <form action="updateApproval.php" method="post">
        <table cellspacing="0" cellpadding="0" align="center" border="2px">
            <tr>
                <th>Reference No</th>
                <td><input type="text" name="referenceNo" placeholder="referenceNo" value="<?php echo $data['referenceNo'] ?>" /></td>
            </tr>     
            
            <tr>
                <th>serialNo</th>
                <td><input type="text" name="serialNo" placeholder="serialNo" value="<?php echo $data['serialNo'] ?>" /></td>
            </tr>
            <tr>
                <th>Application No</th>
                <td><input type="text" name="applicationNo" placeholder="applicationNo" value="<?php echo $data['applicationNo'] ?>" /></td>
            </tr>
			<tr>
                <th>Applicant Name</th>
                <td><input type="text" name="applicantName" placeholder="applicantName" value="<?php echo $data['applicantName'] ?>" /></td>
            </tr>
			<tr>
                <th>Applicant Address</th>
                <td><input type="text" name="applicantAddress" placeholder="applicantAddress" value="<?php echo $data['applicantAddress'] ?>" /></td>
            </tr>
			<tr>
                <th>Site Name</th>
                <td><input type="text" name="siteName" placeholder="siteName" value="<?php echo $data['siteName'] ?>" /></td>
            </tr>
			<tr>
                <th>Bank Name</th>
                <td><input type="text" name="bankName" placeholder="bankName" value="<?php echo $data['bankName'] ?>" /></td>
            </tr>
			<tr>
                <th>Account Type</th>
                <td><input type="text" name="accountType" placeholder="accountType" value="<?php echo $data['accountType'] ?>" /></td>
            </tr>
			<tr>
                <th>Branch Address</th>
                <td><input type="text" name="branchAddress" placeholder="branchAddress" value="<?php echo $data['branchAddress'] ?>" /></td>
            </tr>
			<tr>
                <th>Account Number</th>
                <td><input type="text" name="accountNumber" placeholder="accountNumber" value="<?php echo $data['accountNumber'] ?>" /></td>
            </tr>
			<tr>
                <th> IFSC</th>
                <td><input type="text" name="IFSC" placeholder="IFSC" value="<?php echo $data['IFSC'] ?>" /></td>
            </tr>
			<tr>
                <th>Name of Account</th>
                <td><input type="text" name="nameOfAccount" placeholder="nameOfAccount" value="<?php echo $data['nameOfAccount'] ?>" /></td>
            </tr>
			<tr>
                <th>Rent</th>
                <td><input type="text" name="rent" placeholder="rent" value="<?php echo $data['rent'] ?>" /></td>
            </tr>
			<tr>
                <th>Advance</th>
                <td><input type="text" name="advance" placeholder="advance" value="<?php echo $data['advance'] ?>" /></td>
            </tr>
			<tr>
                <th>agreementLetterNumber</th>
                <td><input type="text" name="agreementLetterNumber" placeholder="agreementLetterNumber" value="<?php echo $data['agreementLetterNumber'] ?>" /></td>
            </tr>
			<tr>
                <th>Mobile</th>
                <td><input type="text" name="Mobile" placeholder="Mobile*" value="<?php echo $data['Mobile'] ?>" readonly /></td>
            </tr>
            <tr>
                <input type="hidden" name="id" value="<?php echo $data['id']?>" />
                <td><center><button type="submit">Save Changes</button></center></td>
                <td><center><a href="showApprovalLetter.php"><button type="button">Back</button></center></a></td>
            </tr>
        </table>
    </form>
 </div>
 
</body>
</html>
 <?php
}
?>
