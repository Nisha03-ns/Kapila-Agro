<?php 
 
include("connection.php");
 
if($_POST) {
    $Company_Name = $_POST['Company_Name'];
 $Company_Name = $_POST['AccountNumber'];
  $AccountType = $_POST['AccountType'];
 $Bank = $_POST['Bank'];
 $IFSC = $_POST['IFSC'];
 $Branch = $_POST['Branch'];
 $BillTo = $_POST['BillTo'];
 $Mobile = $_POST['Mobile'];
 $Address = $_POST['Address'];
 $Pincode = $_POST['Pincode'];
 $Invoice = $_POST['Invoice'];
 $InvoiceDate = $_POST['InvoiceDate'];
 $Status = $_POST['Status'];
 $InvestmentCharge = $_POST['InvestmentCharge'];
 $SubTotal = $_POST['SubTotal'];
 $GST = $_POST['GST'];
 $Total = $_POST['Total'];
    $id = $_POST['id'];
 
    $sql = "UPDATE invoicedetail SET Company_Name = '$Company_Name', Company_Name = '$Company_Name', AccountType = '$AccountType'  ,Bank = '$Bank', IFSC = '$IFSC', Branch = '$Branch', BillTo = '$BillTo' , Mobile = '$Mobile', Address = '$Address', Address = '$Address',  Pincode = '$Pincode', Invoice = '$Invoice', InvoiceDate = '$InvoiceDate'  ,Status = '$Status' ,  InvestmentCharge = '$InvestmentCharge', SubTotal = '$SubTotal',  GST = '$GST',  Total = '$Total'         WHERE id = {$id}";
    if($db->query($sql) === TRUE) {
        echo "<center><br><br><br><br><div id=p2><br><p>Data has been succcessfully updated</p></div></center>";
        echo "<center><div id=p3><a href='../KapilaAgro/editInvoice.php?id=".$id."'><button type='button'>Back</button></a><a href='../KapilaAgro/showInvoiceDetail.php'><button type='button'>Go Back to Admin page</button></a></div></center>";
    } else {
        echo "Erorr while updating record : ". $db->error;
    }
 
    $db->close();
 
}
 
?>
<!DOCTYPE html>
<html>
<head>
 <style type="text/css">
 body{
margin:0;
background-image: url('31.jpg');
}
#p2{

    top: 130px;
    right: 0;
    width: 500px;
    height: 120px;
	font-size: 30px;
	color:Black;
	
}
#p3{

    top: 130px;
    right: 0;
    width: 200px;
    height: 120px;
	font-size: 30px;
	color:Black;
	
}
</style>
 
</head>
</body>
</html>