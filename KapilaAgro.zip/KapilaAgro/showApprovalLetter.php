<?php
include("connection.php");


 ?>
 <!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4B7AAF;
  color: white;
}
</style>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="admin.php">GO Back to Admin Panel Dashboard</a> 
| 
<h2>View Records</h2>
<table id="customers" width="50%" border="2" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>ID</strong></th>
<th><strong>Serial Number</strong></th>
<th><strong>Reference Number</strong></th>
<th><strong>Application Number</strong></th>
<th><strong>Applicant Name</strong></th>
<th><strong>Applicant Address</strong></th>
<th><strong>Mobile</strong></th>
<th><strong>Site Name</strong></th>
<th><strong>Bank Name</strong></th>
<th><strong>Account Type</strong></th>
<th><strong>Branch Address</strong></th>
<th><strong>Account Number</strong></th>
<th><strong>Name Of Account</strong></th>
<th><strong>Rent</strong></th>
<th><strong>Advance</strong></th>
<th><strong>Agreement Letter Number</strong></th>
<th colspan="2"><strong>Options</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="Select * from add_approval_data order by id desc;";
$result = mysqli_query($db,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td align="center"><?php echo $row["id"]; ?></td>
<td align="center"><?php echo $row["serialNo"]; ?></td>
<td align="center"><?php echo $row["referenceNo"]; ?></td>
<td align="center"><?php echo $row["applicationNo"]; ?></td>
<td align="center"><?php echo $row["applicantName"]; ?></td>
<td align="center"><?php echo $row["applicantAddress"]; ?></td>
<td align="center"><?php echo $row["Mobile"]; ?></td>
<td align="center"><?php echo $row["siteName"]; ?></td>
<td align="center"><?php echo $row["bankName"]; ?></td>
<td align="center"><?php echo $row["accountType"]; ?></td>
<td align="center"><?php echo $row["IFSC"]; ?></td>
<td align="center"><?php echo $row["nameOfAccount"]; ?></td>
<td align="center"><?php echo $row["rent"]; ?></td>
<td align="center"><?php echo $row["advance"]; ?></td>
<td align="center"><?php echo $row["agreementLetterNumber"]; ?></td>
<td align="center">
<a href="editApproval.php?id=<?php echo $row["id"]; ?>">Edit</a>
</td>
<td align="center">
<a href="deleteApproval.php?id=<?php echo $row["id"]; ?>">Delete</a>
</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
