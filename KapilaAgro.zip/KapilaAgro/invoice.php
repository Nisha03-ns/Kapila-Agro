<?php
include("connection.php");

	
if($_GET['id']) {
    $id = $_GET['id'];
    
    $sql="SELECT * FROM addcustomer WHERE id='".$id."' ";
  
 $query = mysqli_query($db,$sql);
 
  
 while($data = mysqli_fetch_array($query)){
    
 
?>

<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


input[type=print] {
	
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=print]:hover {
  background-color: #45a049;
}
button {
	background: #2B6BB5;
	padding: 8px 20px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}

</style>
</head>
<body>
<div class="container">
	<center><h2>Invoice Details</h2>
		<img  src="images/demo/logo.png" style="height: 100px">
		
	</center>
	<div class="container">
		<p style="float:right">
		
		KAPILA AGRO PRIVATE LTD.<br>
		Head Office Address -<br>
		Nalawadi,Post office & Nvalgund,<br>
		Dharwad, Karnatka,India<br>
		Pincode - 580023<br><br>
		Corporate Office -<br>
		Krishnagar Akola<br>
		Akola, Maharastra, India<br>
		Pincode - 444104<br>
</div>
<div class="container">

<p> __________________________________________________________________________________________________________________________________</p>
<br><br><br>
	<h6><b>Dear Sir/Ma'am,</b></h6>
	<p>Kapil Agro family Welcomes you. We are please to inform you that your application has been accepted. The address mentioned by you has been investigation secretly by the Company team. Given below are the details as captured in Kapila Agro Recorded with us. Please go through the carefully and intimate to us immediately, in case of any disrepancy.</p>
</div><br><br>
 
<br><br>
<table border="2" align="center">
          <form action="invoicedata.php" method="POST">
    <div class="row" >
      <div class="col-25">
        <label for="name"> This is your registered mobile number please click on search to get your invoice letter : </label>
      </div>
      <div class="col-75">
        <input type="text" name="get_Mobile"  value="<?php echo $data['Mobile'] ?>" readonly  />
		  <input type="hidden" name="id" value="<?php echo $data['id']?>" />            
           
      </div>
	  
	<br><br><br>
	
    <div class="row">
	  <center><br><br><br>
	  
     <button type="submit" class="btn btn-primary" name="search_by_Mobile" align="center" >Search</button> 
	
	</center>
    </div>

</div></form></table><br><br><br>

	 <?php
}
	 ?>


</body>
</html>

<?php
    
	 }
	 else
	 {
		 ?>
		
		 <?php
		 
	 }
   ?> 
  

