<?php
include("connection.php");
?>
<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <div id="logo" class="fl_left">
     <h1><a href="index.php">कपिला  Agro</a></h1>
    <img  src="images/demo/logo.png" style="float:right;position: absolute;top: 2px;right: 8px;font-size: 18px; height: 120px"></div>
  </header>
</div>
<div class="wrapper row2">
  <nav id="mainav" class="hoc clear"> 
    <ul class="clear">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a class="drop" href="">Product</a>
        <ul>
          <li><a class="drop" href="">Kapila Pashu Ahar</a>
            <ul>
              <li><a href="BuffaloSpecialKapila.php">Buffalo Special</a></li>
              <li><a href="DairySpecialKapila.php">Dairy Special</a></li>
              <li><a href="UttamPalletKapila.php">Uttam Pallet (Super)</a></li>
			   <li><a href="SantulitPalletKapila.php">Santulit Pallet (Balance)</a></li>
            </ul>
          </li>
		  <li><a class="drop" href="">Milkomore Pashu Ahar</a>
            <ul>
               <li><a href="BuffaloSpecialMilkomore.php">Buffalo Special</a></li>
              <li><a href="DairySpecialMilkomer.php">Dairy Special</a></li>
              <li><a href="UttamPalletMilkomore.php">Uttam Pallet (Super)</a></li>
			   <li><a href="SantulitPalletMilomore.php">Santulit Pallet (Balance)</a></li>
            </ul>
          </li>
        </ul>
      </li>
       <li><a class="drop" href="">Bussiness</a>
        <ul>
          <li><a  href="KapilaFMCG.php">Kapila (FMCG)</a> </li>
           <li><a  href="Urbancrave.php">Ubrbancrave</a>  </li>
           <li><a  href="wholesale.php">Hundred Wholesale</a>  </li>
		  </ul></li>
      <li><a href="gallery.php">Media</a></li>
      <li><a href="contact.php">Contact Us</a></li>
	   <li><a href="apply.php">Apply Online</a></li>
      <li><a href="checkStatus.php">Check Status</a></li>
    </ul>
  </nav>
</div>
<div class="wrapper row3" >
  <section class="hoc container clear" > 
    <div class="sectiontitle">
      <h1 class="heading">_____ABOUT US_____</h1></br>
      <p>We believe in our products can fulfill the true need.</p>
	 
    </div>
    <div class="group">
      <article class="one_third first" align="right"><a href="#"><img class="btmspace-30" src="images/demo/logo.png" style = "margin-right: 600px; height:230px; "></a>
        <center><h6 class="nospace heading" >GLANCE</h6><br><br><br>
      </article>
	  <h2>COMPANY AT A GLANCE</h2><br>
	  <li>Kapila Agro Group, is one of the major animal feed producer in India with a production capacity is about to 1600 MT of cattle feed per day. Since long time, the company has expanded and brings up very close relationship with farmers by providing them best quality of products. Also, we are providing them creative and innovative ideas to produce cattle feed as well as educating them on farming and animal husbandry practices</li><br>
 <li>Nowadays, with more than 100 educated people and three large-scale manufacturing companies, including with 3 automates and 3 semi-automated plants are involved with Kapil Agro Family.</li><br>
<li>Places like Uttar Pradesh and Punjab along with 700 networks, C&F, distributors, dealers, agents are part of this family. We proud that we are the market leader in animal feed in North India.</li><br>
    </div>
	<br><br>
	<div class="group">
      <article class="one_third first" align="right"><a href="#"><img class="btmspace-30" src="images/demo/vision.jpg" style = "margin-right: 500px; height:200px; "></a>
        <center><h6 class="nospace heading" >VISION</h6><br>
      </article>
	  <h2>VISION</h2><br>
	  <li>Kapila Krishi Udyog Ltd. is the most widely known and well thought of private cattle feed company in India. </li><br>
	   <li>To achieve this company wishes to expand its horizon into varied geographies through 8-10 Nos of production facilities and 1 Million tons of cattle feed sales across India.</li><br>
	    
		  <br>
    </div>
	<br><br>
	<div class="group">
      <article class="one_third first" align="right"><a href="#"><img class="btmspace-30" src="images/demo/mission.jpg" style = "margin-right: 600px; height:190px; "></a>
        <center><h6 class="nospace heading" >MISSION</h6><br>
      </article>
	  <h2>MISSION</h2><br>
	  <li>To tap into the potential that animal nutrition segment offers with their flagship cattle feed product ‘Kapila Pashu Aahar’ 
	  and establish it as the most recognised brand in India through new standards of corporate performance, reliably delivering quality products to all its customers at competitive prices.</li><br>
		  <br>
    </div>
  </section>
</div>
<div class="wrapper bgded overlay light" style="background-color:#CBD5C4;">
  <article class="hoc cta clear"> 
    <h6>We continuously strive to make meaningful contributions to the communities of which we are part of. By working with our partners, we have now started to touch various places across the country.</h6>
    <footer class="one_quarter"></footer>
  </article>
</div>
<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
        <div class="one_quarter first">
      <h6 class="heading">About Us</h6>
      <ul class="nospace linklist">
        <li><a href="about.php">Company Introduction</a></li>
        <li><a href="about.php">Vision & Mission</a></li>
		<div class="one_quarter"><br><br>
      <h6 class="heading">Media</h6>
      <ul class="nospace linklist">
        <li><a href="gallery.php">Gallery</a></li>
		</ul>
        
    </div>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Products (Kapila Pashu Ahaar)</h6>
      <ul class="nospace linklist">
        <li><a href="BuffaloSpecialMilkomore.php">Buffalo Special</a></li>
        <li><a href="DairySpecialMilkomer.php">Dairy Special</a></li>
        <li><a href="UttamPalletMilkomore.php">Uttam Pallet (Super)</a></li>
		<li><a href="SantulitPalletMilomore.php">Santulit Pallet (Balance)</a></li>
      </ul><br>
	  <h6 class="heading">Products (Milkomore Pashu Ahaar)</h6>
      <ul class="nospace linklist">
        <li><a href="BuffaloSpecialMilkomore.php">Buffalo Special</a></li>
        <li><a href="DairySpecialMilkomer.php">Dairy Special</a></li>
        <li><a href="UttamPalletMilkomore.php">Uttam Pallet (Super)</a></li>
		<li><a href="SantulitPalletMilomore.php">Santulit Pallet (Balance)</a></li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Business</h6>
      <ul class="nospace linklist">
       <li><a  href="KapilaFMCG.php">Kapila (FMCG)</a> </li>
           <li><a  href="Ubrbancrave.php">Ubrbancrave</a>  </li>
           <li><a  href="wholesale.php">Hundred Wholesale</a>  </li><br><br><br>
		   <a href="apply.php"><h6 class="heading">Apply Online</h6></a>
			<a href="checkStatus.php"><h6 class="heading">Check Status</h6></a>
    </div>
	<div class="one_quarter">
      <h6 class="heading">Contact Us</h6>
      <ul class="nospace btmspace-30 linklist contact">
	  <li><i class="fa fa-map-marker"></i>
          <address>
          Head Office - Nalawadi Post office,&amp; Nvalgund, Dharwad, Karnataka, India(580023)
          </address>
        </li>
        <li><i class="fa fa-map-marker"></i>
          <address>
          Corporate Office - Krishnagar Akola &amp; Akola, Maharastra, India0(444104)
          </address>
        </li>
        <li><i class="fa fa-phone"></i> +91  834 685 4232</li>
        <li><i class="fa fa-envelope-o"></i> support@kapilaagro.in</li>
      </ul>
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
      </ul>
    </div>
  </footer>
</div>
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <center><p>Copyright &copy; 2017 - All Rights Reserved - kapilaagro.in</p></center>
  </div>
</div>
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>