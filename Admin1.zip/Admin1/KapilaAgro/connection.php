<?php
$user ='root';
$pass = '';
$db = 'kapilaagrodb';

$db = new mysqli('localhost', $user, $pass, $db) or die ("unable to connect");
?>