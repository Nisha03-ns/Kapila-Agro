<?php
include("connection.php");

if($_POST) {
    $Name = $_POST['Name'];
    $Gender = $_POST['Gender'];
    $MotherName = $_POST['MotherName'];
    $FatherName = $_POST['FatherName'];
	$Mobile = $_POST['Mobile'];
	$Email = $_POST['Email'];
	$Area = $_POST['Area'];
	$Town = $_POST['Town'];
	$District = $_POST['District'];
	$State = $_POST['State'];
    $Pincode = $_POST['Pincode'];
	$Investment = $_POST['Investment'];
	 
    $sql1 = "SELECT `Email`, `Mobile` FROM `addcustomer` WHERE `Mobile`='".$Mobile."' OR `Email`='".$Email."'";
	$result = $db->query($sql1);
    $sql = "INSERT INTO addcustomer (Name, Gender, MotherName, FatherName, Mobile, Email, Area ,Town,District,State, Pincode, Investment) VALUES ('$Name', '$Gender', '$MotherName', '$FatherName', '$Mobile' , '$Email', '$Area' , '$Town', '$District', '$State', '$Pincode', '$Investment')";
    
	   if($result->num_rows >= 1) {
         echo "<center><br><br><br><br><div id=p2><br><p>Email or Mobile number already exist</p></div></center>";
        echo "<center><a href='../KapilaAgro/index.php'><button type='button'>Home</button></a></div></center>";
	
        
    } 
    
     else if ($db->query($sql) === TRUE) {
	 
		
        echo "<center><br><br><br><br><div id=p2><br><p>New Record Successfully Created</p></div></center>";
        echo "<center><a href='../KapilaAgro/index.php'><button type='button'>Home</button></a></div></center>";
     } 
			
			else {
          echo "Error " . $sql . ' ' . $db->connect_error;
         }
    $db->close();
}
 
?>
