 <?php
 include("connection.php");

if($_POST){
	
 $Company_Name = $_POST['Company_Name'];
 $AccountNumber = $_POST['AccountNumber'];
  $AccountType = $_POST['AccountType'];
 $Bank = $_POST['Bank'];
 $IFSC = $_POST['IFSC'];
 $Branch = $_POST['Branch'];
 $BillTo = $_POST['BillTo'];
 $Mobile = $_POST['Mobile'];
 $Address = $_POST['Address'];
 $Pincode = $_POST['Pincode'];
 $Invoice = $_POST['Invoice'];
 $InvoiceDate = $_POST['InvoiceDate'];
 $Status = $_POST['Status'];
 $InvestmentCharge = $_POST['InvestmentCharge'];
 $SubTotal = $_POST['SubTotal'];
 $GST = $_POST['GST'];
 $Total = $_POST['Total'];
 $q = " INSERT INTO invoicedetail(Company_Name, AccountNumber, AccountType, Bank, IFSC, Branch, BillTo, Mobile, Address, Pincode, Invoice,InvoiceDate, Status, InvestmentCharge, SubTotal, GST, Total) VALUES ( '$Company_Name', '$AccountNumber', '$AccountType', '$Bank', '$IFSC', '$Branch', '$BillTo', '$Mobile', '$Address', '$Pincode', '$Invoice', '$InvoiceDate','$Status', '$InvestmentCharge', '$SubTotal', '$GST', '$Total' )";

 
      if ($db->query($q) === TRUE) {
	 
		
        echo "<center><br><br><br><br><div id=p2><br><p>New Record Successfully Created</p></div></center>";
        echo "<center><a href='../KapilaAgro/admin.php'><button type='button'>Go Back to Admil Panel</button></a></div></center>";
     } 
			
			else {
          echo "Error " . $q . ' ' . $db->connect_error;
         }
    $db->close();
}
?>

<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


input[type=print] {
	
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=print]:hover {
  background-color: #45a049;
}
button {
	background: #2B6BB5;
	padding: 8px 20px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}

</style>
</head>
<body>
<div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">Insert Bank Details </h1>
 </div><br>

 <label>Company Name : </label>
 <input type="text" name="Company_Name" class="form-control" required="required"> <br>

 <label> Account Number : </label>
 <input type="text" name="AccountNumber" class="form-control" required="required"> <br>
 
 <label> Account Type : </label>
 <input type="text" name="AccountType" class="form-control" required="required"> <br>
	
	<label> Bank: </label>
 <input type="text" name="Bank" class="form-control" required="required"> <br>
 
 <label> IFSC Code : </label>
 <input type="text" name="IFSC" class="form-control" required="required"> <br>
 
 <label> Branch: </label>
 <input type="text" name="Branch" class="form-control" required="required"> <br>
 
 <label> Mobile: </label>
 <input type="text" name="Mobile" class="form-control" required="required"> <br>
 
 <label> BillTo: </label>
 <input type="text" name="BillTo" class="form-control" required="required"> <br>
 
 <label> Address: </label>
 <input type="text" name="Address" class="form-control" required="required"> <br>
 
 <label> Pincode: </label>
 <input type="text" name="Pincode" class="form-control" required="required"> <br>
 
 <label> Invoice#: </label>
 <input type="text" name="Invoice" class="form-control" required="required"> <br>
 
 <label> Invoice Date: </label>
 <input type="text" name="InvoiceDate" class="form-control" required="required"> <br>
 
 <label> Status: </label>
 <input type="text" name="Status" class="form-control" required="required"> <br>
 
 <label> Investment Charge: </label>
 <input type="text" name="InvestmentCharge" class="form-control" required="required"> <br>
 
  <label> Sub Total: </label>
 <input type="text" name="SubTotal" class="form-control" required="required"> <br>
 
  <label> GST: </label>
 <input type="text" name="GST" class="form-control" required="required"> <br>
 
  <label> Total: </label>
 <input type="text" name="Total" class="form-control" required="required"> <br>
 
 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>
 <br>

 </div>
 </form>
 </div>
</body>
</html>
