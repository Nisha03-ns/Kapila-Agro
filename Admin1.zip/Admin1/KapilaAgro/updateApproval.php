<?php 
 
include("connection.php");
 
if($_POST) {
    $referenceNo = $_POST['referenceNo'];
    
    $serialNo = $_POST['serialNo'];
    $applicationNo = $_POST['applicationNo'];
	$applicantName = $_POST['applicantName'];
	$applicantAddress = $_POST['applicantAddress'];
    $siteName = $_POST['siteName'];
	$bankName = $_POST['bankName'];
	$accountType = $_POST['accountType'];
    $branchAddress = $_POST['branchAddress'];
    $accountNumber = $_POST['accountNumber'];
	$IFSC = $_POST['IFSC'];
    $nameOfAccount = $_POST['nameOfAccount'];
	$rent = $_POST['rent'];
    $advance = $_POST['advance'];
	$agreementLetterNumber = $_POST['agreementLetterNumber'];
    $Mobile = $_POST['Mobile'];
    $id = $_POST['id'];
 
    $sql = "UPDATE add_approval_data SET referenceNo = '$referenceNo', serialNo = '$serialNo', applicationNo = '$applicationNo'  ,applicantName = '$applicantName', siteName = '$siteName', bankName = '$bankName', accountType = '$accountType' , branchAddress = '$branchAddress', accountNumber = '$accountNumber', IFSC = '$IFSC',  nameOfAccount = '$nameOfAccount', rent = '$rent', advance = '$advance'  ,agreementLetterNumber = '$agreementLetterNumber' ,  Mobile = '$Mobile'          WHERE id = {$id}";
    if($db->query($sql) === TRUE) {
        echo "<center><br><br><br><br><div id=p2><br><p>Data has been succcessfully updated</p></div></center>";
        echo "<center><div id=p3><a href='../KapilaAgro/editApproval.php?id=".$id."'><button type='button'>Back</button></a><a href='../KapilaAgro/showApprovalLetter.php'><button type='button'>Go Back to Admin page</button></a></div></center>";
    } else {
        echo "Erorr while updating record : ". $db->error;
    }
 
    $db->close();
 
}
 
?>
<!DOCTYPE html>
<html>
<head>
 <style type="text/css">
 body{
margin:0;
background-image: url('31.jpg');
}
#p2{

    top: 130px;
    right: 0;
    width: 500px;
    height: 120px;
	font-size: 30px;
	color:Black;
	
}
#p3{

    top: 130px;
    right: 0;
    width: 200px;
    height: 120px;
	font-size: 30px;
	color:Black;
	
}
</style>
 
</head>
</body>
</html>