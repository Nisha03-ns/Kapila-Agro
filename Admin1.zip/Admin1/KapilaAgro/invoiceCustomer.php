 <?php

include 'connection.php';

if(isset($_POST['done'])){

 $BillTo = $_POST['BillTo'];
 $Contact = $_POST['Contact'];
 $Address = $_POST['Address'];
 $Pincode = $_POST['Pincode'];
 $Invoice = $_POST['Invoice'];
 $q = " INSERT INTO `testdb`(`BillTo`, `Contact`, `Address`, `Pincode`, `Invoice`) VALUES ( '$BillTo', '$Contact', '$Address', '$Pincode', '$Invoice')";

 $query = mysqli_query($db,$q);
 header('location:invoice.php');
}
?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Insert Details </h1>
 </div><br>

 <label> Bill To: </label>
 <input type="text" name="BillTo" class="form-control"> <br>

 <label> Contact: </label>
 <input type="text" name="Contact" class="form-control"> <br>
 
 <label> Address: </label>
 <input type="text" name="Address" class="form-control"> <br>
 
 <label> Pincode: </label>
 <input type="text" name="Pincode" class="form-control"> <br>
 
 <label> Invoice: </label>
 <input type="text" name="Invoice" class="form-control"> <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>
</body>
</html>