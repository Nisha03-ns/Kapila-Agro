
<?php

include 'connection.php';

if($_POST){
	
 $serialNo = $_POST['serialNo'];
 $Mobile = $_POST['Mobile'];
 $referenceNo = $_POST['referenceNo'];
 $applicationNo = $_POST['applicationNo'];
 $applicantName = $_POST['applicantName'];
 $applicantAddress = $_POST['applicantAddress'];
 $siteName = $_POST['siteName'];
 $bankName = $_POST['bankName'];
 $accountType = $_POST['accountType'];
 $branchAddress = $_POST['branchAddress'];
 $accountNumber = $_POST['accountNumber'];
 $IFSC = $_POST['IFSC'];
 $nameOfAccount = $_POST['nameOfAccount'];
 $rent = $_POST['rent'];
 $advance = $_POST['advance'];
 $agreementLetterNumber = $_POST['agreementLetterNumber'];
 $q = " INSERT INTO add_approval_data(serialNo, referenceNo, applicationNo, applicantName, applicantAddress, Mobile, siteName, bankName, accountType, branchAddress, accountNumber, IFSC, nameOfAccount, rent, advance, agreementLetterNumber) VALUES ( '$serialNo', '$referenceNo', '$applicationNo', '$applicantName', '$applicantAddress', '$Mobile', '$siteName', '$bankName', '$accountType', '$branchAddress', '$accountNumber', '$IFSC', '$nameOfAccount', '$rent', '$advance', '$agreementLetterNumber' )";

 
     if ($db->query($q) === TRUE) {
	 
		
        echo "<center><br><br><br><br><div id=p2><br><p>New Record Successfully Created</p></div></center>";
        echo "<center><a href='../KapilaAgro/admin.php'><button type='button'>Go Back to Admil Panel</button></a></div></center>";
     } 
			
			else {
          echo "Error " . $q . ' ' . $db->connect_error;
         }
    $db->close();
}
?>
<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


input[type=print] {
	
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=print]:hover {
  background-color: #45a049;
}
button {
	background: #2B6BB5;
	padding: 8px 20px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}

</style>
</head>
<body>
<div class="col-lg-6 m-auto">
   <form method="post">
 <br><br><div class="card">

 <div class="card-header bg-dark">
 <h1 class="text-white text-center">Insert Data to create Approval Letter </h1>
 </div><br>
 
 <label> Serial Number </label>
 <input type="text" name="serialNo" id="serialNo"  placeholder="Enter serial number..." required="required"> <br>

 <label> Reference Number </label>
 <input type="text" name="referenceNo" id="referenceNo" placeholder="Enter reference number..." required="required"> <br>

 <label> Application Number </label>
 <input type="text" name="applicationNo" id="applicationNo" placeholder="Enter application number..." required="required"> <br>
	
	<label> Applicant Name </label>
 <input type="text" name="applicantName" id="applicantName" placeholder="Enter applicant name..." required="required"> <br>
 
 <label> Applicant Address </label>
 <input type="text" name="applicantAddress" id="applicantAddress" placeholder="Enter applicant address.." required="required"> <br>
 
 <label> Contact </label>
 <input type="text" name="Mobile"  id="Mobile" placeholder="Enter contact number..." required="required"> <br>
 
 <label> Site Name </label>
 <input type="text" name="siteName" id="siteName" placeholder="Enter site name..." required="required"> <br>
 
  <label> Bank Name </label>
 <input type="text" name="bankName" id="bankName" placeholder="Enter bank name..." required="required"> <br>
 
  <label> Account Type </label>
 <input type="text" name="accountType" id="accountType"  placeholder="Enter account type..." required="required"> <br>
 
  <label> Branch Address </label>
 <input type="text" name="branchAddress" id="branchAddress" placeholder="Enter branch address..." required="required"> <br>
 
  <label> Account Number </label>
 <input type="text" name="accountNumber" id="accountNumber" placeholder="Enter account number..." required="required"> <br>
 
  <label> IFSC Code </label>
 <input type="text" name="IFSC" id="IFSC" placeholder="Enter IFSC code..." required="required"> <br>
 
  <label> Name Of Account </label>
 <input type="text" name="nameOfAccount" id="nameOfAccount" placeholder="Enter name of your account..." required="required"> <br>
 
  <label> Rent </label>
 <input type="text" name="rent" id="rent" placeholder="Enter rent amount..." required="required"> <br>
 
  <label> Advance </label>
 <input type="text" name="advance" id="advance" placeholder="Enter amount for advance..." required="required"> <br>
 
  <label> Agreement Letter Number </label>
 <input type="text" name="agreementLetterNumber" id="agreementLetterNumber" placeholder="Enter agreement letter number..." required="required"> <br>
 
 <input type="submit" name="submit" button class="btn btn-primary"><br>
 <br>

 </div>
</form>
</body>
</html>
