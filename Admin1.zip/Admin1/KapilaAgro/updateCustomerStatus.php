 <?php
 include 'connection.php';
 if(isset($_POST['submit'])){

 $id = $_GET['id'];
 $BillTo = $_POST['BillTo'];
 $Contact = $_POST['Contact'];
 $Address = $_POST['Address'];
 $Pincode = $_POST['Pincode'];
 $Invoice = $_POST['Invoice'];
 $InvoiceDate = $_POST['InvoiceDate'];
 $Status = $_POST['Status'];
 $InvestmentAmout = $_POST['InvestmentAmout'];
 $SubTotal = $_POST['SubTotal'];
 $GST = $_POST['GST'];
 $Total = $_POST['Total'];
 $p = " update customer_status_invoice set id=$id, BillTo='$BillTo', Contact='$Contact', Address='$Address', Pincode='$Pincode', Invoice='$Invoice', InvoiceDate='$InvoiceDate', Status='$Status', InvestmentAmout='$InvestmentAmout', SubTotal='$SubTotal', GST='$GST', Total='$Total', where id=$id  ";
 $query = mysqli_query($db,$p);
 header('location:invoice.php');
 }
?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Update Bill & Invoice Details </h1>
 </div><br>

 <label> Bill To: </label>
 <input type="text" name="BillTo" class="form-control"> <br>

 <label> Contact: </label>
 <input type="text" name="Contact" class="form-control"> <br>
	
	<label> Address: </label>
 <input type="text" name="Address" class="form-control"> <br>
 
 <label> Pincode : </label>
 <input type="text" name="Pincode" class="form-control"> <br>
 
 <label> Invoice#: </label>
 <input type="text" name="Invoice" class="form-control"> <br>
 
 <label> Invoice Date: </label>
 <input type="text" name="InvoiceDate" class="form-control"> <br>
 
 <label> Status: </label>
 <input type="text" name="Status" class="form-control"> <br>
 
 <label> Investment Amount: </label>
 <input type="text" name="InvestmentAmout" class="form-control"> <br>
 
 <label> Sub Total: </label>
 <input type="text" name="SubTotal" class="form-control"> <br>
 
 <label> GST: </label>
 <input type="text" name="GST" class="form-control"> <br>
 
 <label> Total: </label>
 <input type="text" name="Total" class="form-control"> <br>
 
 <button class="btn btn-success" type="submit" name="submit"> Submit </button><br>
 </div>
 </form>
 </div>
</body>
</html>