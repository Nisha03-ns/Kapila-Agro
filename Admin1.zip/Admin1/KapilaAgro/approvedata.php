<?php
include("connection.php");

	if(isset($_POST['search_by_Mobile']))
	{
    $id = $_POST['get_Mobile'];
	
	
    $sql="SELECT * FROM add_approval_data WHERE Mobile='".$id."'";
    $result=mysqli_query($db,$sql);
	
	
	 if(mysqli_num_rows($result) > 0)                
	               {
		           while($row = mysqli_fetch_array($result))
		           {

    
 
?>

<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


input[type=print] {
	
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=print]:hover {
  background-color: #45a049;
}
button {
	background: #2B6BB5;
	padding: 8px 20px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}

</style>
</head>
<body>
<div class="container">
	<center><h2>Approval Document</h2>
		<img  src="images/demo/logo.png" style="height: 100px">
	</center>
	<div class="container">
		<p style="float:right">
		KAPILA AGRO PRIVATE LTD.<br>
		Head Office Address -<br>
		Nalawadi,Post office & Nvalgund,<br>
		Dharwad, Karnatka,India<br>
		Pincode - 580023<br><br>
		Corporate Office -<br>
		Krishnagar Akola<br>
		Akola, Maharastra, India<br>
		Pincode - 444104<br>
</div>
<div class="container">

<p> __________________________________________________________________________________________________________________________________</p>



<br><br><br>
	<h6><b>Dear Sir/Ma'am,</b></h6>
	<p>Kapil Agro family Welcomes you. We are please to inform you that your application has been accepted. The address mentioned by you has been investigation secretly by the Company team. Given below are the details as captured in Kapila Agro Recorded with us. Please go through the carefully and intimate to us immediately, in case of any disrepancy.</p>
</div><br><br>


</div>
 <div class="container">
 <div class="col-lg-12">
 <br><br>
 <h4> Application Details </h4>

 


 <tr class="text-center">
 <tr><td>Serial Number : </td></tr>
 <tr><td> <?php echo $row['serialNo'];  ?> </td></tr><br>
 <tr><td>Reference Number : </td></tr>
 <tr><td> <?php echo $row['referenceNo'];  ?> </td></tr><br>
 <tr><td> Application Number : </td></tr>
<tr> <td> <?php echo $row['applicationNo'];  ?> </td></tr><br>
 <tr><td>Applicant Name : </td></tr>
 <tr><td> <?php echo $row['applicantName'];  ?> </td></tr><br>
  <tr><td>Applicant Address : </td></tr>
 <tr><td> <?php echo $row['applicantAddress'];  ?> </td></tr><br>
 <tr><td>Contact Number : </td></tr>
 <tr><td> <?php echo $row['Mobile'];  ?> </td></tr><br>
  <tr><td>Site Name : </td></tr>
 <tr><td> <?php echo $row['siteName'];  ?> </td></tr><br><p> __________________________________________________________________________________________________________________________________</p><br><h4>Applicant Bank Details</h4>

 <tr><td> Bank Name :</td></tr>
<tr> <td> <?php echo $row['bankName'];  ?> </td></tr><br>
<tr><td> Account Type :</td></tr>
<tr> <td> <?php echo $row['accountType'];  ?> </td></tr><br>
<tr><td> Branch Address :</td></tr>
<tr> <td> <?php echo $row['branchAddress'];  ?> </td></tr><br>
<tr><td> Account Number : </td></tr>
<tr> <td> <?php echo $row['accountNumber'];  ?> </td></tr><br>
<tr><td> IFSC :</td></tr>
<tr> <td> <?php echo $row['IFSC'];  ?> </td></tr><br>
<tr><td> Name Of Account : </td></tr>
<tr> <td> <?php echo $row['nameOfAccount'];  ?> </td></tr><br><br><p> __________________________________________________________________________________________________________________________________</p><br><h4>Applicant Rent & Advance Details</h4>
<tr><td> Rent : </td></tr>
<tr> <td> <?php echo $row['rent'];  ?> </td></tr><br>
<tr><td> Advance : </td></tr>
<tr> <td> <?php echo $row['advance'];  ?> </td></tr><br>
<tr><td> Agreement Letter Number :</td></tr>
<tr> <td> <?php echo $row['agreementLetterNumber'];  ?> </td></tr><br><br>
 </tr><br><br>


 </table>  
 </div>
<br>
<table class="table table-bordered" >
<tr>
<th colspan="4" style="text-align:center">Note : RENT will increase by 10% every year </th>
</tr>
<tr>
<th colspan="4" style="text-align:center">*** THIS IS A COMPUTER GENERATED INVOICE AND DOES NOT REQUIRE SIGNATURE ***</th>
</tr>
<tr>
<th colspan="4" style="text-align:center"># </th>
</tr>
<tr>
<th colspan="4" style="text-align:center">Site servey (ground fisiablity )done within 7 days. </th>
 </tr>
 <tr>
 <th colspan="4" style="text-align:center">Pls pay agreement fee which one is mention on your site status panel</th>
</tr>
<tr>
<th colspan="4" style="text-align:center">which one is mantaion on your site status panel Site acquistion</th>
</tr>
<tr>
<th colspan="4" style="text-align:center">Civil works </th>
</tr>
<tr>
<th colspan="4" style="text-align:center">Foundation design</th>
</tr>
<tr>
<th colspan="4" style="text-align:center">Shelters</th>
</tr>
<tr>
<th colspan="4" style="text-align:center">Networking and structured labling</th>
</tr>
<tr>
<th colspan="4" style="text-align:center">Project management</th>
</tr>
<tr>
<th colspan="4" style="text-align:center">Commissioning</th>
</tr>
</table>
<table class="table">
<tr>
<th style="text-align:right"><h4 style="color:blue">Kapila agro authorized signature</h4></th></tr>
<th colspan="4" style="text-align:right"><img class="btmspace-30" style="float:right" src="images/demo/signature.jpeg"></th>
</tr>
</table>
</div>
</div>      
</div>
<div class="container">
<center>
	<script>
	function printpage() {

    //Get the print button and put it into a variable
    var printButton = document.getElementById("printpagebutton");
	

    //Set the button visibility to 'hidden' 
    printButton.style.visibility = 'hidden';

    //Print the page content
    window.print()

    //Restore button visibility
    printButton.style.visibility = 'visible';
	
} 
</script>
<div class="container">

<center><input id="printpagebutton" class="btn-btn-primary" type="button" value="Print" onclick="printpage()"/></center><br><br>


</div>
<br><br><br>
</div>
 
</body>
</html>
<br><br><br>

  
<?php
    }
	 }
	 else
	 {
		 ?>
		 <tr>
		      <center><br><br><br><br><div id=p2><br><p> Your approval letter is being processes.Please try again later....</p></div></center>
<center><a href='../KapilaAgro/index.php'><button type='button'>Home</button></a></div></center>
		 </tr>
		 <?php
		 
	} }
   ?>