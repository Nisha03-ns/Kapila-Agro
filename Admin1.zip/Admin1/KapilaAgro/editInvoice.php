<?php 
 
include("connection.php");
if($_GET['id']) {
    $id = $_GET['id'];
 
    $sql="SELECT * FROM invoicedetail WHERE id='".$id."'";
    $result = $db->query($sql);
 
    $data = $result->fetch_assoc();
 
    $db->close();
 
?>
<!DOCTYPE html>
<!--
Template Name: Kapila Agro
Author: <a href="https://www.os-templates.com/">OS Templates</a>
Author URI: https://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: https://www.os-templates.com/template-terms
-->
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title>कपिला  Agro</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="icon" type="image/png" href="images/demo/logo.png">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


input[type=print] {
	
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=print]:hover {
  background-color: #45a049;
}
button {
	background: #2B6BB5;
	padding: 8px 20px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}

</style>
</head>
<body>
<br>
<center><h1 id="q2">Make Changes in Invoice letter...</h1></center><br><br><br>
<div id="p4">
    <form action="updateInvoice.php" method="post">
        <table cellspacing="0" cellpadding="0" align="center" border="2px">
            <tr>
                <th>Company Name</th>
                <td><input type="text" name="Company_Name" placeholder="Company_Name" value="<?php echo $data['Company_Name'] ?>" /></td>
            </tr>     
            
            <tr>
                <th>Account Type</th>
                <td><input type="text" name="AccountType" placeholder="AccountType" value="<?php echo $data['AccountType'] ?>" /></td>
            </tr>
            <tr>
                <th>Account Number</th>
                <td><input type="text" name="AccountNumber" placeholder="AccountNumber" value="<?php echo $data['AccountNumber'] ?>" /></td>
            </tr>
			<tr>
                <th>Bank</th>
                <td><input type="text" name="Bank" placeholder="Bank" value="<?php echo $data['Bank'] ?>" /></td>
            </tr>
			<tr>
                <th>IFSC</th>
                <td><input type="text" name="IFSC" placeholder="IFSC" value="<?php echo $data['IFSC'] ?>" /></td>
            </tr>
			<tr>
                <th>Branch</th>
                <td><input type="text" name="Branch" placeholder="Branch" value="<?php echo $data['Branch'] ?>" /></td>
            </tr>
			<tr>
                <th>Bill To</th>
                <td><input type="text" name="BillTo" placeholder="BillTo" value="<?php echo $data['BillTo'] ?>" /></td>
            </tr>
			<tr>
                <th>Mobile</th>
                <td><input type="text" name="Mobile" placeholder="Mobile" value="<?php echo $data['Mobile'] ?>" /></td>
            </tr>
			<tr>
                <th>Address</th>
                <td><input type="text" name="Address" placeholder="Address" value="<?php echo $data['Address'] ?>" /></td>
            </tr>
			<tr>
                <th>Pincode</th>
                <td><input type="text" name="Pincode" placeholder="Pincode" value="<?php echo $data['Pincode'] ?>" /></td>
            </tr>
			<tr>
                <th> Invoice#</th>
                <td><input type="text" name="Invoice" placeholder="Invoice" value="<?php echo $data['Invoice'] ?>" /></td>
            </tr>
			<tr>
                <th>Invoice Date</th>
                <td><input type="InvoiceDate" name="InvoiceDate" placeholder="InvoiceDate" value="<?php echo $data['InvoiceDate'] ?>" /></td>
            </tr>
			<tr>
                <th>Status</th>
                <td><input type="text" name="Status" placeholder="Status" value="<?php echo $data['Status'] ?>" /></td>
            </tr>
			<tr>
                <th>Investment Charge</th>
                <td><input type="text" name="InvestmentCharge" placeholder="InvestmentCharge" value="<?php echo $data['InvestmentCharge'] ?>" /></td>
            </tr>
			<tr>
                <th>Sub Total</th>
                <td><input type="text" name="SubTotal" placeholder="SubTotal" value="<?php echo $data['SubTotal'] ?>" /></td>
            </tr>
			<tr>
                <th>GST</th>
                <td><input type="text" name="GST" placeholder="GST*" value="<?php echo $data['GST'] ?>"  /></td>
            </tr>
			<tr>
                <th>Total</th>
                <td><input type="text" name="Total" placeholder="Total" value="<?php echo $data['Total'] ?>" /></td>
            </tr>
            <tr>
                <input type="hidden" name="id" value="<?php echo $data['id']?>" />
                <td><center><button type="submit">Save Changes</button></center></td>
                <td><center><a href="showInvoiceDetail.php"><button type="button">Back</button></center></a></td>
            </tr>
        </table>
    </form>
 </div>
 
</body>
</html>
 <?php
}
?>
